<div class="sidebar" id="mySidebar">
  <a class="closebtn" href="javascript:void(0)" onclick="closeNav()">✘</a>
  <a>.:MENU:.</a>
  <a href="logout.php">Logout</a>
  <br><br>
  <a href="#">Malea Energy</a>
  <a href="#">Malea OM Toraja</a>
  <a href="#">Tamboli Energy</a>
  <a href="#">Bukaka: BMS</a>
  <a href="#">BMS Pusat</a>

</div>