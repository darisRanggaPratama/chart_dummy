# Web Grafik Gaji dan Tabel (CRUD)

Aplikasi web ini dibuat menggunakan:
1. PHP 8
2. MySQL 8
3. Bootstrap 5
4. Chart.js
5. Datatables.js


