<?php
// Connection details
$server = 'localhost'; // Server name
$user = 'hyvoycom_rangga'; // User name
$password = '20061988rangga'; // User password
$database = 'hyvoycom_payroll'; // Database name

// Connection to database
$connect = mysqli_connect($server, $user, $password, $database);
